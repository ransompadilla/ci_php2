	<head>
		<meta charset="utf-8">
		<title>Online Grading System</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="">
		<!--[if ie]><meta content='IE=8' http-equiv='X-UA-Compatible'/><![endif]-->
		<!-- bootstrap -->
		<script>var base_url = '<?php echo base_url() ?>';</script>
		<link href="<?php echo base_url('assets/Bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet">
    	<link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/fonts/web-fonts-with-css/css/fontawesome-all.min.css') ?>">
		<link href="<?php echo base_url('assets/Bootstrap/css/style.css') ?>" rel="stylesheet">
	
	</head>