<?php include 'head.php'; ?>
<div id="schedule">
	<table class="table table-stripped">
	<th>CODE</th><th>SUB CODE</th><th>ROOM</th>
	<th>START TIME</th><th>END TIME</th><th>DAY</th>
	<?php 
		foreach ($stud_sched as $t_sched) :?>
		<tr>
			<td><?= $t_sched->sched_code ?></td>
			<td><?= $t_sched->sub_code ?></td>
			<td><?= $t_sched->section_room ?></td>
			<td><?= Date('h:i:A', strtotime($t_sched->start_time)); ?></td>
			<td><?= Date('h:i:A', strtotime($t_sched->end_time)); ?></td>
			<td><?= $t_sched->day ?></td>
		</tr>
	<?php endforeach; ?>
	</table>
</div>
<?php include 'foot.php'; ?>