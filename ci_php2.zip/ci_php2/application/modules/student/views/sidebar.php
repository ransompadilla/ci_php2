
<div class="row">
	<div class="col-md-1"></div>
	<div class="col-md-10">
		<div id="div-profile-img"></div>
		<hr>
		<div style="text-align: center">
			<h4><?= $student->stud_fname.' '.$student->stud_mi.'. '.$student->stud_lname ?></h4>
		</div>
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4"><p>Student</p></div>
		</div>
	</div>
</div>