<?php include 'head.php'; ?>
<br>
<div id="aboutme">
	<b>Address:</b> <?= $student->stud_addr ?><hr>
	<b>Gender:</b></b> <?= $student->stud_gender ?><hr>
	<b>B-Date:</b> <?= Date('F j, Y', strtotime($student->stud_bday)) ?><hr>
	<b>Contact#:</b> <?= $student->stud_phone ?><hr>
</div>
<?php include 'foot.php'; ?>