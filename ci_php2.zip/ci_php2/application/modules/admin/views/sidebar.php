
<div class="row">
	<div class="col-md-1"></div>
	<div class="col-md-10">
		<div id="div-profile-img"></div>
		<hr>
		
				<div style="text-align: center">
				<h5><?= ucfirst($admin->admin_email) ?></h5>
				</div>
				<br>
	</div>
</div>