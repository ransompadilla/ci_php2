<!-- <?php
	$info = "";
	if(isset($_GET->idno)){
		$idno = $_GET->idno;$table = 'tbl_student';$where='stud_idno';
		$stud = $this->model->CheckDATA($table,$where, array($idno));
		$stud_sched = $this->model->GetStudentSched($idno);
	}
?> -->
<?php $this->load->view('head'); ?>
<hr>
		<div class="row">
			<div class="col-md-4" >
				<hr>
				<div class="row">
					<div class="col-md-3"></div>
					<div class="col-md-8">
						<div style="height: 140px;width: 140px;background: #b0b0b0;border-radius: 50%;"></div>
					</div>
				</div>
				
				<div style="text-align: center">
				<h5><?= $stud->stud_fname.' '.$stud->stud_mi.'. '.$stud->stud_lname ?></h5>
				</div>
				<div class="row">
					<div class="col-md-4"></div>
					<div class="col-md-4"><p>Student</p></div>
					<div class="col-md-11" style="text-align: center">IDNO: <?= $stud->stud_idno?></div>
				</div>
				<hr>
				<b>Information:</b><br><br>
				<b>Address:</b> <?= $stud->stud_addr?><hr>
				<b>Gender:</b></b> <?= $stud->stud_gender?><hr>
				<b>B-Date:</b> <?= Date('F j, Y', strtotime($stud->stud_bday)) ?><hr>
				<b>Contact#:</b> <?= $stud->stud_phone?><hr>
				<div class="row">
					<div class="col-md-4">
						<a href="index.php?page=profile/edit" class="btn btn-primary" style="width: 100%"><i class="fa fa-edit"></i> Edit</a>
					</div>
				</div>
			</div>
			<div class="col-md-8" style="background: #fefefe;">
				<ul class="nav nav-tabs">
					<li class="" style="width: 33%;"><a class="t_time_sched btn btn-default" style="width: 100%; "  href="#stud_remarks" data-toggle="tab"> REMARKS</a></li>
					<li class="" style="width: 34%;background: #e0e0e0;"><a class="t_assign_sched btn btn-default" style="width: 100%; "  href="#stud_time_sched" data-toggle="tab"> SUBJECTS</a></li>
					<li class="" style="width: 33%;background: #e0e0e0;"><a class="t_assign_subject btn btn-default" style="width: 100%; "  href="#set_schedule" data-toggle="tab"> ASSIGN SUBJECT</a></li>
				</ul>
				<div class="tab-content">
					<div id="stud_remarks" class="tab-pane fadein active">
						<?php if($stud_sched != ""): ?>
						<table class="table table-stripped">
							<th>SUB CODE</th><th>DESCRIPTION</th><th>REMARKS</th>
							<?php 
							foreach ($stud_sched as $remark) :?>
									<tr>
										<td><?= $remark->sub_code ?></td>
										<td><?= $remark->sub_desc ?></td>
										<td><?= $remark->remarks ?></td>
									</tr>
							<?php endforeach; ?>
							</table>
						<?php else: ?><br>
							<h3>No Data Found!</h3>
						<?php endif; ?>
					</div>
					<div id="stud_time_sched" class="tab-pane">
					<?php if($stud_sched != ""): ?>
						<table class="table table-stripped">
							<th>CODE</th><th>SUB CODE</th><th>ROOM</th>
							<th>START TIME</th><th>END TIME</th><th>DAY</th>
							<?php 
							foreach ($stud_sched as $t_sched) :?>
									<tr>
										<td><?= $t_sched->sched_code ?></td>
										<td><?= $t_sched->sub_code ?></td>
										<td><?= $t_sched->section_room ?></td>
										<td><?= Date('h:i:A', strtotime($t_sched->start_time)); ?></td>
										<td><?= Date('h:i:A', strtotime($t_sched->end_time)); ?></td>
										<td><?= $t_sched->day ?></td>
									</tr>
							<?php endforeach; ?>
							</table>
						<?php else: ?><br>
							<h3>No Data Found!</h3>
						<?php endif; ?>
					</div>

				<div id="set_schedule" class="tab-pane">
					<?php if($t_schedules != ""): ?>
					<form action="<?php echo site_url('admin/assign_student_sched'); ?>" method="post" class="changepassword">

					<table class="table table-stripped">
					<th>CODE</th><th>SUB CODE</th><th>ROOM</th>
					<th>START TIME</th><th>END TIME</th><th>DAY</th>
					<th>STATUS</th><th><i class="fa fa-cog"></i></th>
					<?php 
					foreach ($t_schedules as $t_sched) :
					$row = $this->AdminModel->CheckStudentSched(array('stud_idno'=>$stud->stud_idno, 'sched_code'=>$t_sched->sched_code)); 
						if($row != ""): ?>
							<tr>
								<td><?= $t_sched->sched_code ?></td>
								<td><?= $t_sched->sub_code ?></td>
								<td><?= $t_sched->section_room ?></td>
								<td><?= Date('h:i:A', strtotime($t_sched->start_time)); ?></td>
								<td><?= Date('h:i:A', strtotime($t_sched->end_time)); ?></td>
								<td><?= $t_sched->day ?></td>
								<td><?= $t_sched->sub_status ?></td>
								<td>
									<input type="hidden" name="stud_idno" value="<?= $stud->stud_idno ?>">
									<input type="hidden" name="sub_idno[]" value="<?= $t_sched->sub_idno ?>">
									<input type="checkbox" name="sched_code[]" value="<?= $t_sched->sched_code ?>" checked>
								</td>
							</tr>
						<?php else: ?>
							<tr>
								<td><?= $t_sched->sched_code ?></td>
								<td><?= $t_sched->sub_code ?></td>
								<td><?= $t_sched->section_room ?></td>
								<td><?= Date('h:i:A', strtotime($t_sched->start_time)); ?></td>
								<td><?= Date('h:i:A', strtotime($t_sched->end_time)); ?></td>
								<td><?= $t_sched->day ?></td>
								<td><?= $t_sched->sub_status ?></td>
								<td>
									<input type="hidden" name="stud_idno" value="<?= $stud->stud_idno ?>">
									<input type="hidden" name="sub_idno[]" value="<?= $t_sched->sub_idno ?>">
									<input type="checkbox" name="sched_code[]" value="<?= $t_sched->sched_code ?>">
								</td>
							</tr>
						<?php endif; ?>
					<?php endforeach; ?>
					</table>
					<button class="btn btn-primary" type="submit" name="assign_student_sched">Submit</button>
					</form><br>
					<div class="msg_signin"></div>
					<?php else: ?>
						<h3>No Data Found!</h3>
					<?php endif; ?>
				</div>
				</div>
			</div>
		</div>
<?php $this->load->view('foot'); ?>