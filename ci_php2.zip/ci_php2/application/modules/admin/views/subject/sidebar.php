
<div class="row">
	<div class="col-md-1"></div>
	<div class="col-md-10">
		<div class="container">
			<ul>
				<li class=""><a href="<?php echo base_url('admin/subject/view') ?>">View</a></li>	
				<li><a href="<?php echo base_url('admin/subject/create') ?>">Create</a></li>	
			</ul>
		</div>
	</div>
</div>