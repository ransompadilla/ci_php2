<?php $this->load->view('head'); ?>
<br>
<div class="row">
	<div class="col-md-3">
		<?php $this->load->view('subject/sidebar'); ?>
	</div>
	<div class="col-md-8">
		<form action="<?php echo site_url('admin/subject_insert'); ?>" method="post" class="changepassword">
			<div class="row">
				<div class="col-sm-2"><b>Code:</b> </div>
				<div class="col-sm-10">
					<input type="text" class="form-control" name="code" placeholder="Code">
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="col-sm-2"><b>Description:</b> </div>
				<div class="col-sm-10">
					<input type="text" class="form-control" name="description" placeholder="Description">
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="col-md-4">
					<button type="submit" name="create_subject" class="btn btn-primary" style="width: 100%"><i class="fa fa-check"></i> Create</button>
				</div>
			</div>
		</form><br>
		<div class="msg_signin"></div>
	</div>
	
</div>
<?php $this->load->view('foot'); ?>