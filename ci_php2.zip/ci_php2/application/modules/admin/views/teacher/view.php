<?php $this->load->view('head'); ?>
<br>
<div class="row">
	<div class="col-md-3">
		<?php $this->load->view('teacher/sidebar'); ?>
	</div>
	<div class="col-md-8">
		<table class="table table-stripped">
			<th>IDNO</th><th>NAME</th><th>GENDER</th><th>ADDRESS</th><th>CONTACT</th>
			<?php foreach ($teachers as $teacher) : ?>
				<tr>
					<td><a href="<?php echo base_url('admin/teacher/'.$teacher->teacher_idno) ?>"><?= $teacher->teacher_idno ?></a></td>
					<td><?= $teacher->teacher_lname.', '.$teacher->teacher_fname.' '.$teacher->teacher_mi ?>.</td>
					<td><?= $teacher->teacher_gender ?></td>
					<td><?= $teacher->teacher_addr ?></td>
					<td><?= $teacher->teacher_phone ?></td>
				</tr>
			<?php endforeach; ?>
		</table>
	</div>
	
</div>
<?php $this->load->view('foot'); ?>