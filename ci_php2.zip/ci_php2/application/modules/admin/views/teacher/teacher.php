<?php $this->load->view('head'); ?>
<br>
		<div class="row">
			<div class="col-md-4" >
				<hr>
				<div class="row">
					<div class="col-md-3"></div>
					<div class="col-md-8">
						<div style="height: 140px;width: 140px;background: #b0b0b0;border-radius: 50%;"></div>
					</div>
				</div>
				
				<div style="text-align: center">
				<h5><?= $teacher->teacher_fname.' '.$teacher->teacher_mi.'. '.$teacher->teacher_lname ?></h5>
				</div>
				<div class="row">
					<div class="col-md-4"></div>
					<div class="col-md-11" style="text-align: center">IDNO: <?= $teacher->teacher_idno?></div>
				</div>
				<hr>
				<b>Information:</b><br><br>
				<b>Address:</b> <?= $teacher->teacher_addr?><hr>
				<b>Gender:</b></b> <?= $teacher->teacher_gender?><hr>
				<b>B-Date:</b> <?= Date('F j, Y', strtotime($teacher->teacher_bday)) ?><hr>
				<b>Contact#:</b> <?= $teacher->teacher_phone?><hr>
				<div class="row">
					<div class="col-md-4">
						<a href="#" class="btn btn-primary" style="width: 100%"><i class="fa fa-edit"></i> Edit</a>
					</div>
				</div>
			</div>
			<div class="col-md-8" style="background: #fefefe;">
				<ul class="nav nav-tabs">
					<li class="" style="width: 33%;"><a class="t_time_sched btn btn-default" style="width: 100%; "  href="#t_time_sched" data-toggle="tab"> Time Schedule</a></li>
					<li class="" style="width: 34%;background: #e0e0e0;"><a class="t_assign_sched btn btn-default" style="width: 100%; "  href="#t_assign_sched" data-toggle="tab"> Assign Section</a></li>
					<li class="" style="width: 33%;background: #e0e0e0;"><a class="t_assign_subject btn btn-default" style="width: 100%; "  href="#t_assign_subject" data-toggle="tab"> Assign Subject</a></li>
				</ul>
				<div class="tab-content">
					<div id="t_time_sched" class="tab-pane fadein active">
						<div>
							<?php if($t_schedule != "") : ?>
							<table class="table table-stripped">
							<th>CODE</th><th>SUB CODE</th><th>ROOM</th><th>START TIME</th>
							<th>END TIME</th><th>DAY</th><th><i class="fa fa-user"></i></th>
							<?php foreach ($t_schedule as $t_sched) :
							$count = $this->TeacherModel->countStudent(array($t_sched->sched_code));
							?>

								<tr>
									<td><a href="<?php echo base_url('admin/teacher/'.$t_idno.'/'.$t_sched->sched_code) ?>"><?= $t_sched->sched_code ?></a></td>
									<td><?= $t_sched->sub_code ?></td>
									<td><?= $t_sched->section_room ?></td>
									<td><?= Date('h:i:A', strtotime($t_sched->start_time)); ?></td>
									<td><?= Date('h:i:A', strtotime($t_sched->end_time)); ?></td>
									<td><?= $t_sched->day ?></td>
									<td>(<?= $count->count ?>)</td>
								</tr>
							<?php endforeach; ?>
							</table>
							<?php else: ?><br>
								<h3>No Data Found!</h3>
							<?php endif; ?>
						</div>
					</div>
					<div id="t_assign_sched" class="tab-pane">
						<form action="<?php echo site_url('admin/assign_teacher_sched'); ?>" method="post" class="changepassword">
							<hr>
							<div class="row">
								<div class="col-md-3">
									<b>SCHED CODE: </b>
								</div>
								<div class="col-md-9">
									<input type="text" class="form-control" name="sched_code" maxlength="7" required="">
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="col-md-3">
									<b>Handled Subject: </b>
								</div>
								<div class="col-md-9">
									<select class="form-control" name="sub_idno" required="">
										<option value="">---</option>
									<?php foreach($t_assign_sched as $ts):?>
										<option value="<?= $ts->sub_idno ?>"><?= $ts->sub_code ?></option>
									<?php endforeach; ?>
								</select>
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="col-md-3">
									<b>Section/Room: </b>
								</div>
								<div class="col-md-9">
									<select class="form-control" name="section_id" required="">
										<option value="">---</option>
									<?php foreach($section as $sec):?>
										<option value="<?= $sec->section_id ?>"><?= $sec->section_room ?></option>
									<?php endforeach; ?>
								</select>
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="col-md-3">
									<b>Start Time: </b>
								</div>
								<div class="col-md-9">
									<input type="time" name="start_time" class="form-control" required="">
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="col-md-3">
									<b>End Time: </b>
								</div>
								<div class="col-md-9">
									<input type="time" name="end_time" class="form-control" required="">
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="col-md-3">
									<b>Day: </b>
								</div>
								<div class="col-md-9">
									<select class="form-control" name="day">
										<option value="MWF">MWF</option>
										<option value="TTH">TTH</option>
										<option value="SAT">SAT</option>
									</select>
								</div>
							</div>
							<hr>
							<input type="hidden" name="teacher_idno" value="<?= $teacher->teacher_idno ?>">
							<button class="btn btn-primary" type="submit" name="assign_teacher_sched">Submit</button>
						</form><br>
							<div class="msg_signin"></div>
					</div>
					<div id="t_assign_subject" class="tab-pane">

						<div id="subject-available">
							<?php if($subject != "") : ?>
							<form action="<?php echo site_url('admin/assign_teacher_subject'); ?>" method="post" class="changepassword">
							<table class="table table-stripped">
							<th>CODE</th><th>Description</th><th>Assign</th>
							<?php 
							foreach ($subject as $sub) : 
								$check = $this->AdminModel->CheckTeacherSubject(array('teacher_idno'=>$t_idno, 'sub_idno'=>$sub->sub_idno));
							if($check != ""){ ?>
								<tr>
									<td><?= $sub->sub_code ?></td>
									<td><?= $sub->sub_desc ?></td>
									<td>
										<input type="hidden" name="teacher_idno" value="<?= $teacher->teacher_idno ?>">
										<input type="checkbox" name="sub_idno[]" value="<?= $sub->sub_idno ?>" checked>
									</td>
								</tr>
							<?php } else { ?>
									<tr>
										<td><?= $sub->sub_code ?></td>
										<td><?= $sub->sub_desc ?></td>
										<td>
											<input type="hidden" name="teacher_idno" value="<?= $teacher->teacher_idno ?>">
											<input type="checkbox" name="sub_idno[]" value="<?= $sub->sub_idno ?>">
										</td>
									</tr>
							<?php } ?>
							<?php endforeach; ?>
							</table>
							<button class="btn btn-primary" type="submit" name="assign_subject_teacher">Submit</button>
							</form>
							<br>
							<div class="msg_signin"></div>
							<?php else:?><br>
								<h3>No Data Found!</h3>
							<?php endif;?>
						</div>
					</div>
				</div>
			</div>
		</div>
<?php $this->load->view('foot'); ?>