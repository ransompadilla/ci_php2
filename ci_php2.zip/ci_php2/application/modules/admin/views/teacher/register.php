<?php $this->load->view('head'); ?>
<br>
<div class="row">
	<div class="col-md-3">
		<?php $this->load->view('teacher/sidebar'); ?>
	</div>
	<div class="col-md-8">
		<form action="<?php echo site_url('admin/teacher_insert'); ?>" method="post" class="changepassword">
					<div class="row">
						<div class="col-md-2">
							IDNO:
						</div>
						<div class="col-md-10">
							<input class="form-control" type="text" name="idno" required="">
						</div>
					</div>
					<hr>
					<div class="row">
						<div class="col-md-5">
							<input class="form-control" type="text" name="fname" placeholder="First Name" required="">
						</div>
						<div class="col-md-5">
							<input class="form-control" type="text" name="lname" placeholder="Last Name" required="">
						</div>
						<div class="col-md-2">
							<input class="form-control" type="text" name="mi" placeholder="MI" required="">
						</div>
					</div><br>
					<div class="row">
						<div class="col-md-12">
							<input class="form-control" type="text" name="address" placeholder="Address" required="">
						</div>
					</div><br>
					<div class="row">
						<div class="col-md-12">
							<select class="form-control" name="gender">
								<option value="">Choose Gender</option>
								<option value="Male">Male</option>
								<option value="Female">Female</option>
							</select>
						</div>
					</div><br>
					<div class="row">
						<div class="col-md-12">
							<input class="form-control" type="date" name="bdate" required="">
						</div>
					</div><br>
					<div class="row">
						<div class="col-md-12">
							<input class="form-control" type="text" name="phone" placeholder="Phone" required="">
						</div>
					</div><br>
					<div class="row">
						<div class="col-md-6">
							<button class="btn btn-primary" type="submit" name="register_teacher" style="width: 100%">Register</button>
						</div>

						<div class="col-md-6">
							<a href="<?php echo base_url('admin/teacher/view') ?>" class="btn btn-danger" style="width: 100%">Cancel</a>
						</div>
					</div>
		</form>
		<div class="msg_signin"></div>
	</div>
	
</div>
<?php $this->load->view('foot'); ?>