<?php
class AdminModel extends MY_Model{

	public function __construct(){
		parent::__construct();
	}

    public $t_table = 'tbl_teacher';
    public $st_table = 'tbl_student';
    public $a_table = 'tbl_admin';
    public $sec_table = 'tbl_section';
	
    public function insertData($table, $data){
    	$query = $this->insert($table, $data);
        return ($query == true ? true:false);
    }
    public function GetRow($data){
    	return $this->getWhereRow($this->a_table, $data);
    }
    public function GetUserRow($table, $data){
        return $this->getWhereRow($table, $data);
    }
    public function GetAllData($data){
        return $this->getAll($data);
    }
    public function authCheck($data){
        $query = $this->getWhereRow($this->a_table, $data);
        return ($query == true ? $query : false);
    }
    public function countStudent($data){
        $sql = "SELECT count(sched_code) as count FROM tbl_studentsubject where sched_code = ?";
        $query = $this->db->query($sql, $data);
        return ($query->num_rows() > 0 ? $query->row() : false);
    }
    
    public function getTeacherSched(){
    	$this->db->select('*');
        $this->db->from('schedule a');
        $this->db->join('tbl_teacher b', 'a.teacher_idno=b.teacher_idno', 'inner');
        $this->db->join('tbl_subject c', 'a.sub_idno=c.sub_idno', 'inner');
        $this->db->join('tbl_section d', 'a.section_id=d.section_id', 'inner');
        $this->db->where('a.status', 'active');
        $query = $this->db->get();
        return ($query->num_rows() > 0 ? $query->result() : false);
    }
    public function CheckStudentSched($data){
        return $this->getWhereRow('tbl_studentsubject', $data);
    }
    public function CheckTeacherSubject($data){
        return $this->getWhereRow('tbl_teachersubject', $data);
    }
    public function GetStudentsWhere($data){
        $this->db->select('*');
        $this->db->from('tbl_studentsubject a');
        $this->db->join('tbl_student b', 'a.stud_idno=b.stud_idno', 'inner');
        $this->db->where('a.sched_code', $data);
        $query = $this->db->get();
        return ($query->num_rows() > 0 ? $query->result() : false);
    }
    public function GetStudentRemarks($data){
        $this->db->select('*');
        $this->db->from('tbl_studentsubject a');
        $this->db->join('tbl_subject b', 'a.sub_idno=b.sub_idno', 'inner');
        $this->db->where('a.stud_idno', $data);
        $query = $this->db->get();
        return ($query->num_rows() > 0 ? $query->result() : false);
    }
    public function GetSchedDetailsWhere($data){
        $this->db->select('*');
        $this->db->from('schedule a');
        $this->db->join('tbl_subject b', 'a.sub_idno=b.sub_idno', 'inner');
        $this->db->join('tbl_section c', 'a.section_id=c.section_id', 'inner');
        $this->db->where('a.sched_code', $data);
        $query = $this->db->get();
        return ($query->num_rows() > 0 ? $query->row() : false);
    }
    public function getTeacherAssignSubject($data){
        $this->db->select('*');
        $this->db->from('tbl_teachersubject a');
        $this->db->join('tbl_subject b', 'a.sub_idno=b.sub_idno', 'inner');
        $this->db->where('a.teacher_idno', $data);
        $query = $this->db->get();
        return ($query->num_rows() > 0 ? $query->result() : false);
    }
    public function changePassword($data, $where){
        $query = $this->update($this->table, $data, $where);
        return ($query == true ? true:false);
    }
}


