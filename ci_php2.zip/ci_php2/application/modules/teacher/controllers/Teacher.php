<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Teacher extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('TeacherModel');
		$this->load->model('student/StudentModel');
   	}
   	public function index(){
   		redirect('teacher/login');
   	}
   	public function login(){

   		$this->page('login', '');
   	}
	public function register(){
   		$this->page('register', '');
   	}
   	public function logout(){
		$this->session->set_userdata('user_info', '');
		$this->session->set_userdata('is_logged', false);
		$this->session->unset_userdata('user_info');
		$this->session->unset_userdata('is_logged');
		$this->session->sess_destroy();
		redirect('teacher');
	}
	public function signin(){
		$response = array();
	
		// set validation rules
		$this->form_validation->set_rules('idno', 'IDNO', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');			
		
		if($this->form_validation->run()){

			// set variables from the form
			$idno = $this->input->post('idno');
			$password = $this->input->post('password');
            
			$checklogin = $this->TeacherModel->authCheck(array('teacher_idno' => $idno, 'teacher_password'=>$password));
			
			if($checklogin['status'] == true){

				$this->session->set_userdata('user_info', $checklogin['data']);
				$this->session->set_userdata('is_logged', true);
				$response['status'] = true;
				$response['msg'] = "Successful. ";
				header('Content-type:application/json');
				echo json_encode($response);
				//redirect('remarks');
				exit;	
				
			}else{
				$response['status'] = false;
				$response['msg'] = "Account does not exist. ";
				header('Content-type:application/json');
				echo json_encode($response);
				exit;
			}
				
			
		}else{
			$response['success'] = false;
           	$response['msg'] = validation_errors();
           	echo json_encode($response);
		}
			
	}
	public function change(){
		$response = array();
	
		// set validation rules
		$this->form_validation->set_rules('teacher_idno', 'IDNO', 'trim|required|max_length[11]');
		$this->form_validation->set_rules('new_password', 'New Password', 'trim|required|max_length[15]');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|matches[new_password]');			
		
		if($this->form_validation->run()){

			// set variables from the form
			$idno = $this->input->post('teacher_idno');
			$new = $this->input->post('new_password');
            
			$check = $this->TeacherModel->changePassword(array('teacher_password' => $new), array('teacher_idno'=>$idno));
			
			if($check == true){
				$response['status'] = true;
				$response['msg'] = "Successful. ";
				header('Content-type:application/json');
				echo json_encode($response);
				exit;	
				
			}else{
				$response['status'] = false;
				$response['msg'] = "Failed to Change your password!. ";
				header('Content-type:application/json');
				echo json_encode($response);
				exit;
			}
				
			
		}else{
			$response['success'] = false;
           	$response['msg'] = validation_errors();
			header('Content-type:application/json');
           	echo json_encode($response);
		}
	}
	public function home(){
		$idno = $this->IDNO();
		$arr = array('teacher_idno'=>$idno);
		$a_data['teacher'] = $this->TeacherModel->getRow($arr);
		$a_data['t_schedule'] = $this->TeacherModel->GetTeacherSchedWhere($idno);
		$this->page('home', $a_data);
	}
	public function mystudents($sched_code = ""){
		$idno = $this->IDNO();
		$arr = array('teacher_idno'=>$idno);
		$a_data['teacher'] = $this->TeacherModel->getRow($arr);
		$a_data['t_students'] = $this->TeacherModel->GetStudentsWhere($sched_code);
		$a_data['_sched'] = $this->TeacherModel->GetSchedDetailsWhere($sched_code);
		$a_data['count'] = $this->TeacherModel->countStudent(array($sched_code));
		$a_data['t_schedule'] = $this->TeacherModel->getTeacherSchedWhere($sched_code);
		$this->page('mystudents', $a_data);
	}
	public function IDNO(){
		if($this->session->userdata('is_logged') == true){
			return $this->session->userdata('user_info')->teacher_idno;
		}
		else{
			redirect('login');
		}
	}
}
