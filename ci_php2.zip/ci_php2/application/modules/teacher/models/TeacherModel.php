<?php
class TeacherModel extends MY_Model{

	public function __construct(){
		parent::__construct();
	}

    public $table = 'tbl_teacher';
	
    public function RegisterUser($data){
    	return $this->insert($this->table, $data);
    }
    public function GetRow($data){
    	return $this->getWhereRow($this->table, $data);
    }
    public function authCheck($data){
        $query = $this->getWhereRow($this->table, $data);
        
        if ($query != "") {
            $ret['status'] = true;
            $ret['data'] = $query;
            return $ret;
        } else {
            $ret['status'] = false;
            $ret['data'] = '';
            return $ret;
        }
    }
    public function countStudent($data){
        $sql = "SELECT count(sched_code) as count FROM tbl_studentsubject where sched_code = ?";
        $query = $this->db->query($sql, $data);
        return ($query->num_rows() > 0 ? $query->row() : false);
    }
    public function GetTeacherSchedWhere($data){
        $this->db->select('*');
        $this->db->from('schedule a');
        $this->db->join('tbl_subject b', 'a.sub_idno=b.sub_idno', 'inner');
        $this->db->join('tbl_section c', 'a.section_id=c.section_id', 'inner');
        $this->db->where('a.teacher_idno', $data);
        $query = $this->db->get();
        return ($query->num_rows() > 0 ? $query->result() : false);
    }
    public function GetStudentsWhere($data){
        $this->db->select('*');
        $this->db->from('tbl_studentsubject a');
        $this->db->join('tbl_student b', 'a.stud_idno=b.stud_idno', 'inner');
        $this->db->where('a.sched_code', $data);
        $query = $this->db->get();
        return ($query->num_rows() > 0 ? $query->result() : false);
    }
    public function GetSchedDetailsWhere($data){
        $this->db->select('*');
        $this->db->from('schedule a');
        $this->db->join('tbl_subject b', 'a.sub_idno=b.sub_idno', 'inner');
        $this->db->join('tbl_section c', 'a.section_id=c.section_id', 'inner');
        $this->db->where('a.sched_code', $data);
        $query = $this->db->get();
        return ($query->num_rows() > 0 ? $query->row() : false);
    }
    public function changePassword($data, $where){
        $query = $this->update($this->table, $data, $where);
        return ($query == true ? true:false);
    }
}


