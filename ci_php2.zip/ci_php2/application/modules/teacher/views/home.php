<?php include 'head.php'; ?>
<div id="time_sched">
	<?php if($t_schedule != ""): ?>
	<table class="table table-stripped">
		<th>CODE</th><th>SUB CODE</th><th>ROOM</th><th>START TIME</th>
		<th>END TIME</th><th>DAY</th><th><i class="fa fa-user"></i></th>

		<?php foreach ($t_schedule as $t_sched) :

		$count = $this->TeacherModel->countStudent(array($t_sched->sched_code));
			?>
		<tr>
			<td><a href="<?php echo base_url('teacher/mystudents/'.$t_sched->sched_code) ?>"><?= $t_sched->sched_code ?></a></td>
			<td><?= $t_sched->sub_code ?></td>
			<td><?= $t_sched->section_room ?></td>
			<td><?= Date('h:i:A', strtotime($t_sched->start_time)); ?></td>
			<td><?= Date('h:i:A', strtotime($t_sched->end_time)); ?></td>
			<td><?= $t_sched->day ?></td>
			<td>(<?= $count->count ?>)</td>
		</tr>
		<?php endforeach; ?>
	</table>
	<?php endif; ?>
</div>
<?php include 'foot.php'; ?>