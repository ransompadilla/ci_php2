<div class="row">
	<div class="col-lg-1"></div>
	<div class="col-lg-10" id="div-header" >
		<p><i class="fa fa-home"></i> <a href="<?php echo base_url('teacher/home') ?>"> Home </a><span class="float-right">You Loggedin as Teacher: <a href="#"><i><?= $teacher->teacher_fname.' '.$teacher->teacher_lname ?></i></a> &nbsp;&nbsp;&nbsp; <a href="<?php echo base_url('teacher/logout') ?>"> logout</a></span></p>
		
	</div>
</div>
<div class="row">
	<div class="col-lg-1"></div>
	<div class="col-lg-10" id="page-border-1px">
		
		<div class="row">
			<div class="col-md-4" >
				<?php include 'sidebar.php'; ?>
			</div>
			<div class="col-md-8" id="div-profile-info"><br>
				