<?php $this->load->view('head'); ?>
		<div class="row">
			<div class="col-md-12" style="background: #fefefe;">
				<hr>
				<div class="row">
					<div class="col-md-3"><i>Subject<br><?= $_sched->sub_code ?></i></div>
					<div class="col-md-5"><i>Time<br><?= Date('h:i:A', strtotime($_sched->start_time)).' - '.Date('h:i:A', strtotime($_sched->end_time)) ?></i></div>
					<div class="col-md-2"><i>Room<br><?= $_sched->section_room ?></i></div>
					<div class="col-md-1"><i>Day<br><?= $_sched->day ?></i></div>
					<div class="col-md-1"><i class="fa fa-user"></i><br>(<?= $count->count ?>)</div>
				</div><br>
				<table class="table table-stripped">
					<th>IDNO</th><th>STUDENT NAME</th><th>GENDER</th><th>REMARKS</th>
				<?php
				foreach ($t_students as $t_stud) : ?>
				<tr>
					<td><?= $t_stud->stud_idno ?></td>
					<td><?= $t_stud->stud_fname.' '.$t_stud->stud_lname.' '.$t_stud->stud_mi ?>.</td>
					<td><?= $t_stud->stud_gender ?></td>
					<td>
						<a href="#myModal<?= $t_stud->stud_idno ?>" id="student_remark" data-toggle="modal" class="btn btn-default"><?= $t_stud->remarks ?></a>
					</td>
				</tr>
				<div id="myModal<?= $t_stud->stud_idno ?>" class="modal fade" role="dialog">
				  <div class="modal-dialog">

				    <!-- Modal content-->
				    <div class="modal-content">
				      <div class="modal-header">
				        <p class="modal-title">
				        	<div class="row">
									<div class="col-md-3"><i>Subject<br><?= $_sched->sub_code ?></i></div>
									<div class="col-md-6"><i>Time<br><?= Date('h:i:A', strtotime($_sched->start_time)).' - '.Date('h:i:A', strtotime($_sched->end_time)) ?></i></div>
									<div class="col-md-2"><i>Room<br><?= $_sched->section_room ?></i></div>
									<div class="col-md-1"><i>Day<br><?= $_sched->day ?></i></div>
									
								</div>
				        </p>
				        <button type="button" class="close" data-dismiss="modal">&times;</button>
				      </div>
				      <div class="modal-body">
				        <h4>Name: <i><?= $t_stud->stud_fname.' '.$t_stud->stud_lname.' '.$t_stud->stud_mi ?>.</i></h4>
				      </div>
				      <div class="modal-footer">
				      	<form action="<?php echo site_url('teacher/change'); ?>" method="post" class="changepassword">
				      		<input type="text" class="form-control" name="stud_idno" >
				      		<input type="text" class="form-control" name="sched_code" >
				      		<input type="text" class="form-control" name="remark" placeholder="Remark">
				        	<button type="submit" name="submit_remark" class="btn btn-primary">Submit</button>
				      	</form>
				      	
				      </div>
				    </div>

				  </div>
				</div>
				 <?php endforeach; ?>
				 </table>
			</div>


<?php $this->load->view('foot'); ?>