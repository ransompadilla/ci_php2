<?php $this->load->view('head'); ?>
<br>
<div class="row">
	<div class="col-md-3">
		<?php $this->load->view('subject/sidebar'); ?>
	</div>
	<div class="col-md-8">
		<table class="table table-stripped">
		<th>CODE</th><th>Description</th>
		<?php foreach ($subject as $sub) : ?>
			<tr>
				<td><?= $sub->sub_code ?></td>
				<td><?= $sub->sub_desc ?></td>
			</tr>
		<?php endforeach; ?>
		</table>
	</div>
	
</div>
<?php $this->load->view('foot'); ?>