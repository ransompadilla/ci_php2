<?php $this->load->view('head'); ?>
<br>
<div class="row">
	<div class="col-md-3">
		<?php $this->load->view('section/sidebar'); ?>
	</div>
	<div class="col-md-8">
		<h3>Create Section</h3><hr>
		<form action="<?php echo site_url('admin/section_insert'); ?>" method="post" class="changepassword">
			<br>
			<div class="row">
				<div class="col-sm-2"><b>Room:</b> </div>
				<div class="col-sm-10">
					<input type="number" class="form-control" name="room" placeholder="Room No.">
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="col-sm-2"><b>Limit:</b> </div>
				<div class="col-sm-10">
					<input type="text" class="form-control" name="limit" placeholder="Limit">
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="col-md-4">
					<button type="submit" name="create_section" class="btn btn-primary" style="width: 100%"><i class="fa fa-check"></i> Create</button>
				</div>
			</div>
		</form>
		<br>
		<div class="msg_signin"></div>
	</div>
	
</div>
<?php $this->load->view('foot'); ?>