<?php $this->load->view('head'); ?>
<br>
<div class="row">
	<div class="col-md-3">
		<?php $this->load->view('section/sidebar'); ?>
	</div>
	<div class="col-md-8">
		<table class="table table-stripped">
			<th>Room No.</th><th>Limit</th>
			<?php foreach ($section as $sec) : ?>
				<tr>
					<td><?= $sec->section_room ?></td>
					<td><?= $sec->section_limit ?></td>
				</tr>
			<?php endforeach; ?>
		</table>
	</div>
	
</div>
<?php $this->load->view('foot'); ?>