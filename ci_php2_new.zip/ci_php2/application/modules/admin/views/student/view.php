<?php $this->load->view('head'); ?>
<br>
<div class="row">
	<div class="col-md-3">
		<?php $this->load->view('student/sidebar'); ?>
	</div>
	<div class="col-md-8">
		<table class="table table-stripped">
		<th>IDNO</th><th>NAME</th><th>GENDER</th><th>ADDRESS</th><th>CONTACT</th>
		<?php foreach ($student as $stud) : ?>
			<tr>
				<td><a href="<?php echo base_url('admin/student/'.$stud->stud_idno) ?>"><?= $stud->stud_idno ?></a></td>
				<td><?= $stud->stud_lname.', '.$stud->stud_fname.' '.$stud->stud_mi ?>.</td>
				<td><?= $stud->stud_gender ?></td>
				<td><?= $stud->stud_addr ?></td>
				<td><?= $stud->stud_phone ?></td>
			</tr>
		<?php endforeach; ?>
		</table>
	</div>
	
</div>
<?php $this->load->view('foot'); ?>