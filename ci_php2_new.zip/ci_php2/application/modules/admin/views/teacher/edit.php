<?php
	$info = "";
	if(isset($_GET['t_idno']) && isset($_GET['edit']) ){
		$t_edit = $_GET['t_idno'];
		$t_edit = $this->model->CheckDATA('tbl_teacher', 'teacher_idno', array($t_edit));
	}
	else{
		$this->redirect('auth=login');
	}
?>
<div class="row">
	<div class="col-md-1">
		
	</div>
	<div class="col-md-10">
		<div class="row">
		<div class="col-md-4" >
				<div id="div-profile-img"></div>
				<hr>
				<div style="text-align: center">
				<h4><?= $t_edit['teacher_fname'].' '.$t_edit['teacher_mi'].'. '.$t_edit['teacher_lname'] ?></h4>
				<i>Teacher</i>
				</div>
				<div class="row">
					<div class="col-md-4"></div>
				</div>
			</div>
			<div class="col-md-8" id="div-profile-info"><br>
			<div class="container">
					<ul class="nav nav-tabs">
					<li class="active" style="width: 50%;"><a class="up_info btn btn-default" style="width: 100%" href="#update_info" data-toggle="tab"> Update Info </a></li>
					<li class="" style="width: 50%;background: #e0e0e0;"><a class="up_security btn btn-default" style="width: 100%; "  href="#update_security" data-toggle="tab"> Update Security Info</a></li>
				</ul>
				<div class="tab-content">
					<div id="update_info" class="tab-pane fadein active">
						<br>
						<form method="post">
						<div class="row">
							<div class="col-sm-5">
								<input type="text" class="form-control" name="fname" placeholder="First Name" value="<?= $t_edit['teacher_fname']?>">
							</div>
							<div class="col-sm-2">
								<input type="text" class="form-control" name="mi" placeholder="MI" value="<?= $t_edit['teacher_mi']?>">
							</div>
							<div class="col-sm-5">
								<input type="text" class="form-control" name="lname" placeholder="Last Name" value="<?= $t_edit['teacher_lname']?>">
							</div>
						</div>
						<hr>
						<div class="row">
							<div class="col-sm-2"><b>Address:</b> </div>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="address" placeholder="Address" value="<?= $t_edit['teacher_addr']?>" />
							</div>
						</div>
						<hr>
						<div class="row">
							<div class="col-sm-2"><b>Gender:</b> </div>
							<div class="col-sm-10">
								<select class="form-control" name="gender">
									<option value="Male" <?= ($t_edit['teacher_gender'] == 'Male') ? 'Selected':'' ?> > Male </option>
									<option value="Female" <?= ($t_edit['teacher_gender'] == 'Female') ? 'Selected':'' ?> > Female </option>
									
								</select>
							</div>
						</div>
						<hr>
						<div class="row">
							<div class="col-sm-2"><b>B-Date:</b> </div>
							<div class="col-sm-10">
								<input type="date" class="form-control" name="bdate" value="<?= $t_edit['teacher_bday']?>">
							</div>
						</div>
						<hr>
						<div class="row">
							<div class="col-sm-2"><b>Contact#:</b> </div>
							<div class="col-sm-10">
								<input type="text" class="form-control" name="contact" value="<?= $t_edit['teacher_phone']?>" placeholder="Phone">
							</div>
						</div>
						<hr>
						<div class="row">
							<div class="col-md-4">
								<button type="submit" name="update_info" class="btn btn-primary" style="width: 100%"><i class="fa fa-check"></i> Update Info</button>
							</div>
						</div>
						</form>
					</div>
					<div id="update_security" class="tab-pane fade">
						<br>
						<form method="post">
							<div class="row">
								<div class="col-sm-2"><b>Email:</b> </div>
								<div class="col-sm-10">
									<input type="email" class="form-control" name="email" value="<?= $t_edit['teacher_email']?>" />
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="col-sm-2"><b>Old Password:</b> </div>
								<div class="col-sm-10">
									<input type="password" class="form-control" name="old_password" />
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="col-sm-2"><b>New Password:</b> </div>
								<div class="col-sm-10">
									<input type="password" class="form-control" name="new_password" />
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="col-sm-2"><b>Confirm Password:</b> </div>
								<div class="col-sm-10">
									<input type="password" class="form-control" name="confirm_password" />
								</div>
							</div>
							<hr>
							<div class="row">
							<div class="col-md-4">
								<button type="submit" name="update_security" class="btn btn-primary" style="width: 100%"><i class="fa fa-check"></i> Update Security</button>
							</div>
						</div>
						</form>
					</div>
				</div>
				</div>
	</div>
</div>