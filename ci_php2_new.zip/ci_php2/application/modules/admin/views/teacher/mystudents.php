<?php $this->load->view('head'); ?>
		<div class="row">
			<div class="col-md-4" >
				<hr>
				<div class="row">
					<div class="col-md-3"></div>
					<div class="col-md-8">
						<div style="height: 140px;width: 140px;background: #b0b0b0;border-radius: 50%;"></div>
					</div>
				</div>
				
				<div style="text-align: center">
				<h5><?= $teacher->teacher_fname.' '.$teacher->teacher_mi.'. '.$teacher->teacher_lname ?></h5>
				</div>
				<div class="row">
					<div class="col-md-4"></div>
					<div class="col-md-11" style="text-align: center">IDNO: <?= $teacher->teacher_idno?></div>
				</div>
				<hr>
				<b>Information:</b><br><br>
				<b>Address:</b> <?= $teacher->teacher_addr?><hr>
				<b>Gender:</b></b> <?= $teacher->teacher_gender?><hr>
				<b>B-Date:</b> <?= Date('F j, Y', strtotime($teacher->teacher_bday)) ?><hr>
				<b>Contact#:</b> <?= $teacher->teacher_phone?><hr>
				<div class="row">
					<div class="col-md-4">
						<a href="#" class="btn btn-primary" style="width: 100%"><i class="fa fa-edit"></i> Edit</a>
					</div>
				</div>
			</div>
			<div class="col-md-8" style="background: #fefefe;">
				<hr>
				<div class="row">
					<div class="col-md-3"><i>Subject<br><?= $_sched->sub_code ?></i></div>
					<div class="col-md-5"><i>Time<br><?= Date('h:i:A', strtotime($_sched->start_time)).' - '.Date('h:i:A', strtotime($_sched->end_time)) ?></i></div>
					<div class="col-md-2"><i>Room<br><?= $_sched->section_room ?></i></div>
					<div class="col-md-1"><i>Day<br><?= $_sched->day ?></i></div>
					<div class="col-md-1"><i class="fa fa-user"></i><br>(<?= $count->count ?>)</div>
				</div><br>
				<table class="table table-stripped">
					<th>IDNO</th><th>STUDENT NAME</th><th>GENDER</th><th>REMARKS</th>
				<?php
				foreach ($t_students as $t_stud) : ?>
				<tr>
					<td><?= $t_stud->stud_idno ?></td>
					<td><?= $t_stud->stud_fname.' '.$t_stud->stud_lname.' '.$t_stud->stud_mi ?>.</td>
					<td><?= $t_stud->stud_gender ?></td>
					<td>NG</td>
				</tr>
				 <?php endforeach; ?>
				 </table>
			</div>
<?php $this->load->view('foot'); ?>