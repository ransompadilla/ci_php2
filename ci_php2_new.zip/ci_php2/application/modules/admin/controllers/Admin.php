<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Admin extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('AdminModel');
		$this->load->model('teacher/TeacherModel');
		$this->load->model('student/StudentModel');
   	}
   	public function index(){
   		redirect('admin/login');
   	}
   	public function login(){

   		$this->page('login', '');
   	}
	public function register(){
   		$this->page('register', '');
   	}
   	public function logout(){
		$this->session->set_userdata('user_info', '');
		$this->session->set_userdata('is_logged', false);
		$this->session->unset_userdata('user_info');
		$this->session->unset_userdata('is_logged');
		$this->session->sess_destroy();
		redirect('admin');
	}
	public function signin(){
		$response = array();
	
		// set validation rules
		$this->form_validation->set_rules('email', 'email', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');			
		
		if($this->form_validation->run()){

			// set variables from the form
			$email = $this->input->post('email');
			$password = $this->input->post('password');
            
			$checklogin = $this->AdminModel->authCheck(array('admin_email' => $email, 'admin_password'=>$password));
			
			if($checklogin != ""){

				$this->session->set_userdata('user_info', $checklogin);
				$this->session->set_userdata('is_logged', true);
				$response['status'] = true;
				$response['msg'] = "Successful. ";
				header('Content-type:application/json');
				echo json_encode($response);
				//redirect('remarks');
				exit;	
				
			}else{
				$response['status'] = false;
				$response['msg'] = "Account does not exist. ";
				header('Content-type:application/json');
				echo json_encode($response);
				exit;
			}
				
			
		}else{
			$response['success'] = false;
           	$response['msg'] = validation_errors();
           	echo json_encode($response);
		}
			
	}
	public function change(){
		$response = array();
	
		// set validation rules
		$this->form_validation->set_rules('teacher_idno', 'IDNO', 'trim|required|max_length[11]');
		$this->form_validation->set_rules('new_password', 'New Password', 'trim|required|max_length[15]');
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'trim|required|matches[new_password]');			
		
		if($this->form_validation->run()){

			// set variables from the form
			$idno = $this->input->post('teacher_idno');
			$new = $this->input->post('new_password');
            
			$check = $this->TeacherModel->changePassword(array('teacher_password' => $new), array('teacher_idno'=>$idno));
			
			if($check == true){
				$response['status'] = true;
				$response['msg'] = "Successful. ";
				header('Content-type:application/json');
				echo json_encode($response);
				exit;	
				
			}else{
				$response['status'] = false;
				$response['msg'] = "Failed to Change your password!. ";
				header('Content-type:application/json');
				echo json_encode($response);
				exit;
			}
				
			
		}else{
			$response['success'] = false;
           	$response['msg'] = validation_errors();
			header('Content-type:application/json');
           	echo json_encode($response);
		}
	}

	public function section_insert(){
		$response = array();
	
		// set validation rules
		$this->form_validation->set_rules('room', 'room', 'trim|required');
		$this->form_validation->set_rules('limit', 'limit', 'trim|required');			
		
		if($this->form_validation->run()){

			// set variables from the form
			$room = $this->input->post('room');
			$limit = $this->input->post('limit');
            
			$check = $this->AdminModel->insertData('tbl_section', array('section_room' => $room, 'section_limit'=>$limit));
			
			if($check == true){
				$response['status'] = true;
				$response['msg'] = "Successful. ";
				header('Content-type:application/json');
				echo json_encode($response);
				//redirect('remarks');
				exit;	
				
			}else{
				$response['status'] = false;
				$response['msg'] = "failed to insert data. ";
				header('Content-type:application/json');
				echo json_encode($response);
				exit;
			}
				
			
		}else{
			$response['success'] = false;
           	$response['msg'] = validation_errors();
			header('Content-type:application/json');
           	echo json_encode($response);
		}
			
	}
	public function subject_insert(){
		$response = array();
	
		// set validation rules
		$this->form_validation->set_rules('code', 'code', 'trim|required');
		$this->form_validation->set_rules('description', 'description', 'trim|required');			
		
		if($this->form_validation->run()){

			// set variables from the form
			$code = $this->input->post('code');
			$desc = $this->input->post('description');
            
			$check = $this->AdminModel->insertData('tbl_subject', array('sub_code' => $code, 'sub_desc'=>$desc));
			
			if($check == true){
				$response['status'] = true;
				$response['msg'] = "Successful. ";
				header('Content-type:application/json');
				echo json_encode($response);
				//redirect('remarks');
				exit;	
				
			}else{
				$response['status'] = false;
				$response['msg'] = "failed to insert data. ";
				header('Content-type:application/json');
				echo json_encode($response);
				exit;
			}
				
			
		}else{
			$response['success'] = false;
           	$response['msg'] = validation_errors();
			header('Content-type:application/json');
           	echo json_encode($response);
		}
			
	}
	public function student_insert(){
		$response = array();
		// set validation rules
		$this->form_validation->set_rules('idno', 'idno', 'trim|required|is_unique[tbl_student.stud_idno]');
		$this->form_validation->set_rules('fname', 'fname', 'trim|required');	
		$this->form_validation->set_rules('lname', 'lname', 'trim|required');	
		$this->form_validation->set_rules('mi', 'mi', 'trim|required');	
		$this->form_validation->set_rules('address', 'address', 'trim|required');	
		$this->form_validation->set_rules('gender', 'gender', 'trim|required');	
		$this->form_validation->set_rules('bdate', 'bdate', 'trim|required');	
		$this->form_validation->set_rules('phone', 'phone', 'trim|required');			
		
		if($this->form_validation->run()){
			// set variables from the form
            $info = array(
            		'stud_idno'=>$this->input->post('idno'),
            		'stud_fname'=>$this->input->post('fname'),
            		'stud_lname'=>$this->input->post('lname'),
            		'stud_mi'=>$this->input->post('mi'),
            		'stud_addr'=>$this->input->post('address'),
            		'stud_gender'=>$this->input->post('gender'),
            		'stud_bday'=>$this->input->post('bdate'),
            		'stud_phone'=>$this->input->post('phone'),
            		'stud_password'=>$this->input->post('idno')
            		);
			$check = $this->AdminModel->insertData('tbl_student', $info);
			
			if($check == true){
				$response['status'] = true;
				$response['msg'] = "Successful. ";
				header('Content-type:application/json');
				echo json_encode($response);
				//redirect('remarks');
				exit;	
				
			}else{
				$response['status'] = false;
				$response['msg'] = "failed to insert data. ";
				header('Content-type:application/json');
				echo json_encode($response);
				exit;
			}
				
			
		}else{
			$response['success'] = false;
           	$response['msg'] = validation_errors();
			header('Content-type:application/json');
           	echo json_encode($response);
		}
			
	}
	public function teacher_insert(){
		$response = array();
		// set validation rules
		$this->form_validation->set_rules('idno', 'idno', 'trim|required|is_unique[tbl_teacher.teacher_idno]');
		$this->form_validation->set_rules('fname', 'fname', 'trim|required');	
		$this->form_validation->set_rules('lname', 'lname', 'trim|required');	
		$this->form_validation->set_rules('mi', 'mi', 'trim|required');	
		$this->form_validation->set_rules('address', 'address', 'trim|required');	
		$this->form_validation->set_rules('gender', 'gender', 'trim|required');	
		$this->form_validation->set_rules('bdate', 'bdate', 'trim|required');	
		$this->form_validation->set_rules('phone', 'phone', 'trim|required');			
		
		if($this->form_validation->run()){
			// set variables from the form
            $info = array(
            		'teacher_idno'=>$this->input->post('idno'),
            		'teacher_fname'=>$this->input->post('fname'),
            		'teacher_lname'=>$this->input->post('lname'),
            		'teacher_mi'=>$this->input->post('mi'),
            		'teacher_addr'=>$this->input->post('address'),
            		'teacher_gender'=>$this->input->post('gender'),
            		'teacher_bday'=>$this->input->post('bdate'),
            		'teacher_phone'=>$this->input->post('phone'),
            		'teacher_password'=>$this->input->post('idno')
            		);
			$check = $this->AdminModel->insertData('tbl_teacher', $info);
			
			if($check == true){
				$response['status'] = true;
				$response['msg'] = "Successful. ";
				header('Content-type:application/json');
				echo json_encode($response);
				//redirect('remarks');
				exit;	
				
			}else{
				$response['status'] = false;
				$response['msg'] = "failed to insert data. ";
				header('Content-type:application/json');
				echo json_encode($response);
				exit;
			}
				
			
		}else{
			$response['success'] = false;
           	$response['msg'] = validation_errors();
			header('Content-type:application/json');
           	echo json_encode($response);
		}
			
	}
	public function assign_teacher_subject(){
		$response = array();
		$check = false;
		$this->form_validation->set_rules('teacher_idno', 'idno', 'trim');			
		
		if($this->form_validation->run()){
			// set variables from the form
			$idno = $this->input->post('teacher_idno');
			$sub_idno = $this->input->post('sub_idno');
			for ($i=0; $i<count($sub_idno);$i++) {
				$_check = $this->AdminModel->CheckTeacherSubject(array('teacher_idno'=>$idno, 'sub_idno'=>$sub_idno[$i]));
				if($_check == ""){
					$chck = $this->AdminModel->insertData('tbl_teachersubject', array('teacher_idno'=>$idno, 'sub_idno'=>$sub_idno[$i]));
					if($chck = true){$check = true;}
				}
			}

			
			
			if($check == true){
				$response['status'] = true;
				$response['msg'] = "Successful. ";
				header('Content-type:application/json');
				echo json_encode($response);
				//redirect('remarks');
				exit;	
				
			}else{
				$response['status'] = false;
				$response['msg'] = "failed to insert data. ";
				header('Content-type:application/json');
				echo json_encode($response);
				exit;
			}
				
			
		}else{
			$response['success'] = false;
           	$response['msg'] = validation_errors();
			header('Content-type:application/json');
           	echo json_encode($response);
		}
	}
	public function assign_teacher_sched(){
		$response = array();
		$this->form_validation->set_rules('sched_code', 'sched_code', 'trim|required|max_length[7]');
		$this->form_validation->set_rules('sub_idno', 'sub_idno', 'trim|required');
		$this->form_validation->set_rules('section_id', 'section_id', 'trim|required');
		$this->form_validation->set_rules('start_time', 'start_time', 'trim|required');
		$this->form_validation->set_rules('end_time', 'end_time', 'trim|required');
		$this->form_validation->set_rules('day', 'day', 'trim|required');
		$this->form_validation->set_rules('teacher_idno', 'teacher_idno', 'trim|required');
		
		if($this->form_validation->run()){
			// set variables from the form
			$info = array(
						'sched_code'=>$this->input->post('sched_code'),
						'sub_idno'=>$this->input->post('sub_idno'),
						'section_id'=>$this->input->post('section_id'),
						'teacher_idno'=>$this->input->post('teacher_idno'),
						'start_time'=>$this->input->post('start_time'),
						'end_time'=>$this->input->post('end_time'),
						'day'=>$this->input->post('day')
					);
			$check = $this->AdminModel->insertData('schedule', $info);
					
			if($check == true){
				$response['status'] = true;
				$response['msg'] = "Successful. ";
				header('Content-type:application/json');
				echo json_encode($response);
				//redirect('remarks');
				exit;	
				
			}else{
				$response['status'] = false;
				$response['msg'] = "failed to insert data. ";
				header('Content-type:application/json');
				echo json_encode($response);
				exit;
			}
				
			
		}else{
			$response['success'] = false;
           	$response['msg'] = validation_errors();
			header('Content-type:application/json');
           	echo json_encode($response);
		}
	}
	public function assign_student_sched(){
		$response = array();
		$check = false;
		$this->form_validation->set_rules('stud_idno', 'idno', 'trim|required');			
		
		if($this->form_validation->run()){
			// set variables from the form
			$idno = $this->input->post('stud_idno');
			$sched_code = $this->input->post('sched_code');
			$sub_idno = $this->input->post('sub_idno');
			for ($i=0; $i<count($sched_code);$i++) {
				$_check = $this->AdminModel->CheckStudentSched(array('stud_idno'=>$idno, 'sched_code'=>$sched_code[$i]));
				if($_check == ""){
					$chck = $this->AdminModel->insertData('tbl_studentschedule', array('stud_idno'=>$idno, 'sched_code'=>$sched_code[$i]));
					$this->AdminModel->insertData('tbl_studentsubject', array('stud_idno'=>$idno, 'sub_idno'=>$sub_idno[$i]));
					if($chck = true){$check = true;}
				}
			}
			
			if($check == true){
				$response['status'] = true;
				$response['msg'] = "Successful. ";
				header('Content-type:application/json');
				echo json_encode($response);
				//redirect('remarks');
				exit;	
				
			}else{
				$response['status'] = false;
				$response['msg'] = "failed to insert data. ";
				header('Content-type:application/json');
				echo json_encode($response);
				exit;
			}
				
			
		}else{
			$response['success'] = false;
           	$response['msg'] = validation_errors();
			header('Content-type:application/json');
           	echo json_encode($response);
		}
	}
	public function home(){
		$email = $this->email();
		$arr = array('admin_email'=>$email);
		$a_data['admin'] = $this->AdminModel->getRow($arr);
		$this->page('home', $a_data);
	}
	public function section($data = ""){
		$email = $this->email();
		$arr = array('admin_email'=>$email);
		$a_data['admin'] = $this->AdminModel->getRow($arr);
		$a_data['section'] = $this->AdminModel->GetAllData('tbl_section');
		$a_data['page'] = 'section';
		$this->page('section/'.$data, $a_data);
	}
	public function subject($data = ""){
		$email = $this->email();
		$arr = array('admin_email'=>$email);
		$a_data['admin'] = $this->AdminModel->getRow($arr);
		$a_data['subject'] = $this->AdminModel->GetAllData('tbl_subject');
		$a_data['page'] = 'subject';
		$this->page('subject/'.$data, $a_data);
	}
	public function student($data = ""){
		$email = $this->email();
		$table = 'tbl_student';
		$arr = array('admin_email'=>$email);
		$a_data['admin'] = $this->AdminModel->getRow($arr);
		$a_data['student'] = $this->AdminModel->GetAllData($table);
		$a_data['page'] = 'student';
		if($data != 'view' && $data != 'register'){
			$a_data['stud'] = $this->AdminModel->getUserRow($table,array('stud_idno'=>$data));
			$a_data['stud_sched'] = $this->StudentModel->getStudentSched($data);
			$a_data['t_schedules'] = $this->AdminModel->getTeacherSched();
			$this->page('student/student', $a_data);
		}
		else {
			$a_data['stud'] = '';
			$this->page('student/'.$data, $a_data);
		}
	}
	public function teacher($data = "", $sched_code = ""){
		$email = $this->email();
		$table = 'tbl_teacher';
		$arr = array('admin_email'=>$email);
		$a_data['admin'] = $this->AdminModel->getRow($arr);
		$a_data['teachers'] = $this->AdminModel->GetAllData($table);
		$a_data['page'] = 'teacher';
		if($data != 'view' && $data != 'register'){
			if($data != "" && $sched_code == ""){
				$a_data['teacher'] = $this->AdminModel->getUserRow($table,array('teacher_idno'=>$data));
				$a_data['t_assign_sched'] = $this->AdminModel->getTeacherAssignSubject($data);
				$a_data['section'] = $this->AdminModel->GetAllData('tbl_section');
				$a_data['subject'] = $this->AdminModel->GetAllData('tbl_subject');
				$a_data['t_idno'] = $data;
				$a_data['t_schedule'] = $this->TeacherModel->getTeacherSchedWhere($data);
				$this->page('teacher/teacher', $a_data);
			}
			else if($data != "" && $sched_code != ""){
				$a_data['teacher'] = $this->AdminModel->getUserRow($table,array('teacher_idno'=>$data));
				$a_data['t_students'] = $this->TeacherModel->GetStudentsWhere($sched_code);
				$a_data['_sched'] = $this->TeacherModel->GetSchedDetailsWhere($sched_code);
				$a_data['count'] = $this->TeacherModel->countStudent(array($sched_code));
				$a_data['t_idno'] = $data;
				$a_data['t_schedule'] = $this->TeacherModel->getTeacherSchedWhere($data);
				$this->page('teacher/mystudents', $a_data);
			}
		}
		else{
			$this->page('teacher/'.$data, $a_data);
		}
	}
	public function changepassword(){
		$idno = $this->IDNO();
		$arr = array('teacher_idno'=>$idno);
		$a_data['teacher'] = $this->TeacherModel->getRow($arr);
		$this->page('edit', $a_data);
	}
	public function email(){
		if($this->session->userdata('is_logged') == true){
			return $this->session->userdata('user_info')->admin_email;
		}
		else{
			redirect('admin');
		}
	}
}
