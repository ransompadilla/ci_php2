<?php
class StudentModel extends MY_Model{

	public function __construct(){
		parent::__construct();
	}

    public $table = 'tbl_student';
	
    public function RegisterUser($data){
    	return $this->insert($this->table, $data);
    }
    public function GetRow($data){
    	return $this->getWhereRow($this->table, $data);
    }
    public function authCheck($data){
        $query = $this->getWhereRow($this->table, $data);
        
        if ($query != "") {
            $ret['status'] = true;
            $ret['data'] = $query;
            return $ret;
        } else {
            $ret['status'] = false;
            $ret['data'] = '';
            return $ret;
        }
    }
    public function getStudentSched($data){
    	$this->db->select('*');
        $this->db->from('tbl_studentsubject a'); 
        $this->db->join('schedule b', 'a.sched_code=b.sched_code', 'inner');
        $this->db->join('tbl_student c', 'a.stud_idno=c.stud_idno', 'inner');
        $this->db->join('tbl_subject d', 'b.sub_idno=d.sub_idno', 'inner');
        $this->db->join('tbl_section e', 'b.section_id=e.section_id', 'inner');
        $this->db->where('c.stud_idno', $data);
        $query = $this->db->get();
        return ($query->num_rows() > 0 ? $query->result() : false);
    }

    // public function GetStudentRemarks($data){
    //     $this->db->select('*');
    //     $this->db->from('tbl_studentsubject a');
    //     $this->db->join('tbl_subject b', 'a.sub_idno=b.sub_idno', 'inner');
    //     $this->db->join('tbl_student c', 'a.stud_idno=c.stud_idno', 'inner');
    //     $this->db->where($data);
    //     $query = $this->db->get();
    //     return ($query->num_rows() > 0 ? $query->result() : false);
    // }
    public function changePassword($data, $where){
        $query = $this->update($this->table, $data, $where);
        return ($query == true ? true:false);
    }
}


