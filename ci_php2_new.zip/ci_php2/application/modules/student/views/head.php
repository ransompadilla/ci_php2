<div class="row">
	<div class="col-lg-1"></div>
	<div class="col-lg-10" id="div-header" >
		<p>IDNO: <?= $student->stud_idno ?> <span class="float-right">You Loggedin as Student: <a href="#"><i><?= $student->stud_fname.' '.$student->stud_lname ?></i></a> &nbsp;&nbsp;&nbsp; <a href="<?php echo base_url('student/logout') ?>"> logout</a></span></p>
		
	</div>
</div>
<div class="row">
	<div class="col-lg-1"></div>
	<div class="col-lg-10" id="page-border-1px">
		
		<div class="row">
			<div class="col-md-4" >
				<?php include 'sidebar.php'; ?>
			</div>
			<div class="col-md-8" id="div-profile-info"><br>
				<ul class="nav nav-tabs">
					<li style="width: 25%;"><a class="up_info btn btn-default" style="width: 100%" href="<?php echo base_url('student/remarks');?>"> Remarks </a></li>
					<li class="active" style="width: 25%;"><a class="up_info btn btn-default" style="width: 100%" href="<?php echo base_url('student/schedule');?>"> Schedule </a></li>
					<li class="active" style="width: 25%;"><a class="up_info btn btn-default" style="width: 100%" href="<?php echo base_url('student/aboutme');?>"> About me </a></li>
					<li class="" style="width: 25%;background: #e0e0e0;"><a class="up_security btn btn-default" style="width: 100%; "  href="<?php echo base_url('student/changepassword');?>" > Update Security Info</a></li>
				</ul>