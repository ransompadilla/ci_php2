<?php include 'head.php'; ?>
<br>
	<form action="<?php echo site_url('student/change'); ?>" method="post" class="changepassword">
		<div class="row">
		<div class="col-sm-10">
			<input type="hidden" class="form-control" name="stud_idno" value="<?= $student->stud_idno ?>" />
		</div>
		</div>
		<div class="row">
			<div class="col-sm-2"><b>New Password:</b> </div>
			<div class="col-sm-10">
				<input type="password" class="form-control" name="new_password" value="<?php echo set_value('new_password') ?>"/>
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="col-sm-2"><b>Confirm Password:</b> </div>
			<div class="col-sm-10">
				<input type="password" class="form-control" name="confirm_password" />
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="col-md-4">
				<button type="submit" name="update_security" class="btn btn-primary" style="width: 100%"><i class="fa fa-check"></i> Update Security</button>
			</div>
		</div>
	</form>
	<div class="msg_signin"></div>
<?php include 'foot.php'; ?>