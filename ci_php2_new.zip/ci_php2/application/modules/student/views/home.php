<?php include 'head.php'; ?>
<div id="remarks" class="tab-pane fadein active">
	<table class="table table-stripped">
	<th>CODE</th><th>SUB CODE</th><th>REMARKS</th>
	<?php 
		foreach ($stud_sched as $t_sched) :?>
		<tr>
			<td><?= $t_sched->sched_code ?></td>
			<td><?= $t_sched->sub_code ?></td>
			<td><?= $t_sched->remarks ?></td>
		</tr>
	<?php endforeach; ?>
	</table>
</div>
<?php include 'foot.php'; ?>