<section id="wrapper" class="container">
	<div class="row">
		<div class="span4"></div>
<div class="span4">	

	<div class="row text-center">
		<?php
		$notify = $this->session->flashdata('notify');
		 if(isset($notify) && $notify['status'] == true): ?>
		<p class="well well-success"><?php echo $notify['msg']; ?></p>
		<?php else: ?>
		<p class="well well-danger"><?php echo $notify['msg']; ?></p>
		<?php endif; ?>
	</div>			
						<h4 class="title"><span class="text"><strong>Register</strong> Form</span></h4>
						<?php echo form_open_multipart(site_url('user/signup')); ?>
							<fieldset>
								<div class="control-group">
									<label class="control-label">Username</label>
									<div class="controls">
										<input type="text" name="username" placeholder="Enter your username" class="input-xlarge" value="<?php echo set_value('username') ?>">
									</div>
								</div>
								<div class="control-group">
									<label class="control-label">Email address:</label>
									<div class="controls">
										<input type="email" name="email" placeholder="Enter your email" class="input-xlarge" value="<?php echo set_value('email') ?>">
									</div>
								</div>
								<div class="control-group">
									<label class="control-label">Password:</label>
									<div class="controls">
										<input type="password" name="password1" placeholder="Enter your password" class="input-xlarge" value="<?php echo set_value('password1') ?>">
									</div>
								</div>	
								<div class="control-group">
									<label class="control-label">Confirm Password:</label>
									<div class="controls">
										<input type="password" name="password2" placeholder="Enter your password" class="input-xlarge" value="<?php echo set_value('password2') ?>">
									</div>
								</div>							                            
								<div class="control-group">
									<p>Now that we know who you are. I'm not a mistake! In a comic, you know how you can tell who the arch-villain's going to be?</p>
								</div>
								<hr>
								<div class="actions"><input tabindex="9" class="btn btn-inverse large" type="submit" value="Create your account"></div>
							</fieldset>
						<?php echo form_close(); ?>
						<a class="btn btn-default" href="<?php echo base_url('user/login') ?>" >Login</a>
					</div>	
	</div>
</section>