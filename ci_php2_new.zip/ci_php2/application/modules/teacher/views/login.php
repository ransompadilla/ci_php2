<br><br>
<form action="<?php echo site_url('teacher/signin'); ?>" method="post" class="login" id="teacher/home">
	<div class="row">
		<div class="col-md-4">
			
		</div>
		<div class="col-md-4">
			<h1>LOGIN</h1><hr>
			<div class="msg_signin"></div>
			<div class="row">
				<div class="col-md-12">
					<input class="form-control" type="text" name="idno" placeholder="IDNO" value="<?php echo set_value('idno'); ?>" required=""> <?php echo form_error('idno'); ?>
				</div>
			</div><br>
			<div class="row">
				<div class="col-md-12">
					<input class="form-control" type="password" name="password" placeholder="Password" required="">
				</div>
			</div><br>
			<div class="row">
				<div class="col-md-12">
					<button  class="btn btn-primary" type="submit" name="login" style="width: 100%">Login</button>
				</div><br>
				<!-- <a href="index.php?auth=register">Register Account</a> -->
			</div>
		</div>
	</div>
			
</form>