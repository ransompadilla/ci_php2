
<div class="row">
	<div class="col-md-1"></div>
	<div class="col-md-10">
		<div id="div-profile-img"></div>
		<hr>
		
				<div style="text-align: center">
				<h5><?= $teacher->teacher_fname.' '.$teacher->teacher_mi.'. '.$teacher->teacher_lname ?></h5>
				</div>
				<div class="row">
					<div class="col-md-4"></div>
					<div class="col-md-11" style="text-align: center">IDNO: <?= $teacher->teacher_idno?></div>
				</div>
				<hr>
				<b>Information:</b><br><br>
				<b>Address:</b> <?= $teacher->teacher_addr?><hr>
				<b>Gender:</b></b> <?= $teacher->teacher_gender?><hr>
				<b>B-Date:</b> <?= Date('F j, Y', strtotime($teacher->teacher_bday)) ?><hr>
				<b>Contact#:</b> <?= $teacher->teacher_phone?><hr>
				<div class="row">
					<div class="col-md-12">
						<a href="<?php echo base_url('teacher/changepassword') ?>" class="btn btn-primary" style="width: 100%"><i class="fa fa-edit"></i> Update Security(Email/Password)</a>
					</div>
				</div>
				<br>
	</div>
</div>