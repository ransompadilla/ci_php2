
<!DOCTYPE html>
<html lang="en">
		<?php include 'css/css_link.php'; ?>
	<body>
		<?= ($header != "" ? $header : ''); ?>
		<?= ($content != "" ? $content : ''); ?>
		<?= ($footer != "" ? $footer : ''); ?>
		<?php include 'js/js_link.php'; ?>
	</body>
</html>
