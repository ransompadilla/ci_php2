<!-- scripts -->
	<script src="<?php echo base_url('assets/Bootstrap/js/jquery-3.3.1.min.js') ?>"></script>
	<script src="<?php echo base_url('assets/Bootstrap/js/bootstrap.min.js') ?>"></script>	
	<script src="<?php echo base_url('assets/Bootstrap/js/bootstrap.js') ?>"></script>
	<script src="<?php echo base_url('assets/Bootstrap/js/custom.js') ?>"></script>		