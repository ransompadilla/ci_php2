<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Model extends CI_Model {
	function getWhereRow($table, $data){
		$query = $this->db->get_where($table, $data);
		return $query->num_rows() > 0 ? $query->row() : false;
	}
	function getWhereResult($table, $data){
		$query = $this->db->get_where($table, $data);
		return $query->num_rows() > 0 ? $query->result() : false;
	}
	function getAll($table){
		$query = $this->db->get($table);
		return $query->num_rows() > 0 ? $query->result() : false;
	}
	function insert($table, $data){
		return $this->db->insert($table, $data);
	}
	function update($table, $data, $where){
		return $this->db->update($table, $data, $where);
	}
	function delete($table, $data){
		return $this->db->delete($table, $data);
	}
	function order_by($attr, $order){
		return $this->db->order_by($attr, $order);
	}
	function affected_rows(){return $this->db->affected_rows();}
}