<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends MX_Controller
{
	function __construct(){
		parent::__construct();
		//$this->load->module('template');

	}
	function index(){
		
	}
	protected function page($display, $page = array()){
		$a_data['header'] = $this->load->view('header/header');
		$a_data['content'] = $this->load->view($display, $page);
		$a_data['footer'] = $this->load->view('footer/footer');

		$this->load->view('main', $a_data);
	}
	
	function generateRandomString($length) {
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyABCDEFGHIJKLMNOPQRSTUVWXY';
	    $charactersLength = strlen($characters);
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, $charactersLength - 1)];
	    }
	    return $randomString;
	}
}
?>