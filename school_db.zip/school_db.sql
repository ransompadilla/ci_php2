-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2018 at 03:34 AM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `sched_code` varchar(7) NOT NULL,
  `sub_idno` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `teacher_idno` int(11) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `day` varchar(3) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`sched_code`, `sub_idno`, `section_id`, `teacher_idno`, `start_time`, `end_time`, `day`, `status`) VALUES
('2072325', 150, 100, 13142523, '15:30:00', '17:30:00', 'MWF', 'active'),
('2083323', 148, 105, 13142523, '09:30:00', '10:30:00', 'MWF', 'active'),
('2092323', 152, 116, 100232, '09:30:00', '14:30:00', 'MWF', 'active'),
('2097232', 152, 114, 1877263234, '16:30:00', '19:30:00', 'TTH', 'active'),
('7877755', 151, 108, 1877263234, '17:30:00', '20:30:00', 'MWF', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(25) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'Admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_section`
--

CREATE TABLE `tbl_section` (
  `section_id` int(11) NOT NULL,
  `section_room` int(11) NOT NULL,
  `section_limit` int(11) NOT NULL,
  `section_status` varchar(255) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_section`
--

INSERT INTO `tbl_section` (`section_id`, `section_room`, `section_limit`, `section_status`) VALUES
(96, 533, 40, 'active'),
(100, 534, 30, 'active'),
(105, 536, 30, 'active'),
(106, 537, 30, 'active'),
(107, 538, 50, 'active'),
(108, 539, 30, 'active'),
(109, 540, 30, 'active'),
(110, 640, 30, 'active'),
(113, 780, 30, 'active'),
(114, 622, 30, 'active'),
(115, 623, 35, 'active'),
(116, 645, 35, 'active'),
(117, 887, 23, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  `stud_idno` int(11) NOT NULL,
  `stud_fname` varchar(255) NOT NULL,
  `stud_lname` varchar(255) NOT NULL,
  `stud_mi` varchar(1) NOT NULL,
  `stud_addr` varchar(255) NOT NULL,
  `stud_gender` varchar(255) NOT NULL,
  `stud_bday` date NOT NULL,
  `stud_phone` varchar(15) NOT NULL,
  `stud_password` varchar(255) NOT NULL,
  `stud_status` varchar(255) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`stud_idno`, `stud_fname`, `stud_lname`, `stud_mi`, `stud_addr`, `stud_gender`, `stud_bday`, `stud_phone`, `stud_password`, `stud_status`) VALUES
(1, 'fghj', 'fgh', 'h', 'fghj', 'Female', '2013-09-28', '', '1', 'Active'),
(10, 'hhhnkk', 'kjj', 'j', 'jjjkjk', 'Female', '2016-10-29', '', 'ooo', 'Active'),
(11, 'fghjk', 'fghj', 'g', 'hhhdfudhf', 'Female', '1985-06-27', '', 'nnn', 'Active'),
(101, 'jsdfdisjf', 'joijioj', 'o', 'iojoij', 'Female', '1989-08-28', '', 'iii', 'Active'),
(111, 'hhshdf', 'dfdsfds', 'f', 'sfdfdf', 'Female', '2015-10-28', '', 'ggg', 'Active'),
(123, '123', 'ewqewewe', 'e', 'sdfghjk', 'Female', '1984-08-26', '', 'mmm', 'Active'),
(132, 'sfslfjjflj', 'ljsdfjdsf', 'k', 'jsdfdslfjs', 'Male', '1994-09-27', '', 'jhdjfh', 'Active'),
(1001, 'fefe', 'grg', 'o', 'efefef', 'Male', '1998-09-28', '09233423421', '1001', 'Active'),
(1011, 'haynku', 'hay', 'n', 'haynku', 'Female', '1987-04-28', '', 'naku', 'Active'),
(1100, 'hahhah', 'ahah', 'h', 'hfdsfdslfdlskfj', 'Female', '2016-11-29', '', 'taken', 'Active'),
(1110, 'ertyuioyt', 'fghjklg', 'h', 'fklgf', 'Female', '1987-04-28', '', 'bbb', 'Active'),
(1111, 'rfefefe', 'feffffffffffffffffffffffffff', 'e', 'fffffffffffffffffffffffff', 'Male', '2013-08-27', '', '1111', 'Active'),
(1199, 'gsufdfjf', 'ljljlkjlk', 'j', 'sfsfdsf', 'Female', '1990-09-29', '', 'jjj', 'Active'),
(10110, 'hahahha ', 'boom', 'o', 'sdfjdfjdjfdsjf', 'Female', '1985-10-27', '', 'boom', 'Active'),
(11003, 'Nikki', 'Gabriente', 'O', 'Urgello', 'Female', '1995-07-27', '', 'nikki', 'Active'),
(100032, 'ambbboott', 'ambot', 'a', 'ambott', 'Female', '1992-06-28', '', 'ambot', 'Active'),
(100232, 'efefefe', 'fefe', 'o', 'efefef', 'Male', '1998-09-28', '09233423421', '100232', 'Active'),
(111001, 'ngano', 'mani', 'o', 'asfdfdsfs', 'Female', '2016-09-29', '', 'ngano', 'Active'),
(123111, 'afsjdfdsjfijij', 'iiiiiiiiiiiiiiiiiiiiiii', 'i', 'iijiji', 'Male', '1990-08-28', '', '123111', 'Active'),
(1002321, 'jjfjfjsjjjjjjjjjjjjjjjjjjjjj', 'jjjjjjjjjjjjjjjjjjjj', 'j', 'jjjjjjjjjjjjjj', 'Male', '2015-08-27', '09233423421', '1002321', 'Active'),
(1090923, 'hsdhfdsf', 'sdfds', 'd', 'sdfsdfds', 'Male', '2016-09-29', '', '', 'Active'),
(1100232, 'Charnilie', 'Ouano', 'G', 'Orgello Cebu City', 'Female', '1994-06-28', '', '1100232', 'Active'),
(9123232, 'fddsffgh', 'fghj', 'h', 'dfdsdf', 'Male', '2003-10-28', '', '', 'Active'),
(10002232, 'lageh', 'oy', 'o', 'taga asa ko', 'Female', '1996-09-28', '09233423421', '10002232', 'Active'),
(10023112, 'ambot', 'ambot', 'm', 'mamsfmdkfmef', 'Female', '2012-09-28', '09233423421', '10023112', 'Active'),
(11232211, 'oeoreoroeoroero', 'oeroeoeoeoro', 'o', 'eroeroeroroero', 'Male', '2013-08-28', '', '11232211', 'Active'),
(12104899, 'Ransom', 'Carino', 'P', 'Biasong, Talisay City, Cebu', 'Male', '1995-04-28', '', 'qwerty', 'Active'),
(99838774, 'qwertyu', 'qwerty', 'q', 'wertyu', 'Female', '1984-07-26', '', 'wew', 'Active'),
(110000221, 'fkfkdfkdfksdkfkfskkskskksksk', 'kkkkkkkkkkkkkkkkkkkkkkkkkk', 'k', 'kkkkkkkkkkkkkkkkkkkkkkkkk', 'Male', '1988-09-27', '', '110000221', 'Active'),
(143143143, 'Allixa jean', 'Gempesao', 'A', 'Mambaling, Cebu City', 'Female', '1997-08-24', '', '97005cf907e08f34def2266ed9cc1dd5', 'Active'),
(428428824, 'Ghe Mariefe', 'Trazona', 'M', 'Pardo, Talisay City, Cebu', 'Female', '1997-11-16', '', 'trazona', 'Active'),
(667666555, 'hhahggggyfyu', 'gyygg', 'h', 'gjhgghg', 'Male', '2016-09-28', '', 'e61e7de603852182385da5e907b4b232', 'Active'),
(998888888, 'hhhhhhhhhh', 'hhhhhhhh', 'h', 'hgygg', 'Male', '1994-07-28', '', 'bsit', 'Active'),
(2147483647, 'qwerty', 'qwerty', 'q', 'qwerty cebu city', 'Male', '1994-08-28', '', '3f931c18b44ac93ac5b4b6c653f7c0b0', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_studentsubject`
--

CREATE TABLE `tbl_studentsubject` (
  `sc_id` int(11) NOT NULL,
  `stud_idno` int(11) NOT NULL,
  `sched_code` varchar(7) NOT NULL,
  `remarks` decimal(2,1) NOT NULL,
  `sc_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_studentsubject`
--

INSERT INTO `tbl_studentsubject` (`sc_id`, `stud_idno`, `sched_code`, `remarks`, `sc_date`) VALUES
(1, 12104899, '2072325', '2.8', '2018-10-18 01:17:12'),
(3, 12104899, '2083323', '0.0', '2018-10-18 01:27:26'),
(4, 143143143, '2072325', '0.0', '2018-10-18 01:54:11'),
(5, 143143143, '2083323', '0.0', '2018-10-18 10:04:19'),
(6, 143143143, '7877755', '0.0', '2018-10-18 10:04:19'),
(7, 11003, '7877755', '0.0', '2018-10-19 10:32:34'),
(8, 1011, '2092323', '2.1', '2018-10-19 23:37:13'),
(9, 1011, '2072325', '0.0', '2018-10-19 23:37:13'),
(10, 1011, '7877755', '0.0', '2018-10-19 23:38:19'),
(11, 11003, '2092323', '3.2', '2018-10-19 23:47:34'),
(12, 11003, '2072325', '0.0', '2018-10-19 23:47:35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subject`
--

CREATE TABLE `tbl_subject` (
  `sub_idno` int(11) NOT NULL,
  `sub_code` varchar(255) NOT NULL,
  `sub_desc` varchar(255) NOT NULL,
  `sub_status` varchar(255) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_subject`
--

INSERT INTO `tbl_subject` (`sub_idno`, `sub_code`, `sub_desc`, `sub_status`) VALUES
(148, 'Math17', 'Descrete Mathematics', 'closed'),
(149, 'English1C', 'English Comprehensive', 'active'),
(150, 'JAVA 21', 'Java Programming', 'active'),
(151, 'filipino', 'jjoh', 'active'),
(152, 'comprog', 'comprog', 'active'),
(153, '987', '45', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_teacher`
--

CREATE TABLE `tbl_teacher` (
  `teacher_idno` int(11) NOT NULL,
  `teacher_fname` varchar(255) NOT NULL,
  `teacher_lname` varchar(255) NOT NULL,
  `teacher_mi` varchar(1) NOT NULL,
  `teacher_addr` varchar(255) NOT NULL,
  `teacher_gender` varchar(255) NOT NULL,
  `teacher_bday` date NOT NULL,
  `teacher_phone` varchar(11) NOT NULL,
  `teacher_password` varchar(255) NOT NULL,
  `teacher_status` varchar(255) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_teacher`
--

INSERT INTO `tbl_teacher` (`teacher_idno`, `teacher_fname`, `teacher_lname`, `teacher_mi`, `teacher_addr`, `teacher_gender`, `teacher_bday`, `teacher_phone`, `teacher_password`, `teacher_status`) VALUES
(100232, 'Jennifer', 'Amores', 'G', 'ambot taga sa ni siya', 'Female', '1988-09-29', '09234876232', 'amores', 'Active'),
(13142523, 'Dennis', 'Durano', 'P', 'Basak, Cebu City', 'Male', '2015-08-29', '09228776234', 'qwerty', 'Active'),
(100122322, 'jjhuhu', 'huhuh', 'u', 'huhuhu', 'Female', '2014-09-27', '09233423421', '100122322', 'Active'),
(1877263234, 'Gian Carlo', 'Cataraja', 'J', 'Lahug Cebu City', 'Male', '1992-09-29', '09232277746', 'cataraja', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_teachersubject`
--

CREATE TABLE `tbl_teachersubject` (
  `ts_id` int(11) NOT NULL,
  `teacher_idno` int(11) NOT NULL,
  `sub_idno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_teachersubject`
--

INSERT INTO `tbl_teachersubject` (`ts_id`, `teacher_idno`, `sub_idno`) VALUES
(13, 13142523, 148),
(14, 13142523, 150),
(15, 1877263234, 150),
(16, 1877263234, 151),
(17, 1877263234, 152),
(18, 100232, 148),
(19, 100232, 149),
(20, 100232, 150),
(21, 100232, 152);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`sched_code`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_section`
--
ALTER TABLE `tbl_section`
  ADD PRIMARY KEY (`section_id`),
  ADD UNIQUE KEY `section_room` (`section_room`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`stud_idno`);

--
-- Indexes for table `tbl_studentsubject`
--
ALTER TABLE `tbl_studentsubject`
  ADD PRIMARY KEY (`sc_id`);

--
-- Indexes for table `tbl_subject`
--
ALTER TABLE `tbl_subject`
  ADD PRIMARY KEY (`sub_idno`),
  ADD UNIQUE KEY `sub_code` (`sub_code`);

--
-- Indexes for table `tbl_teacher`
--
ALTER TABLE `tbl_teacher`
  ADD PRIMARY KEY (`teacher_idno`);

--
-- Indexes for table `tbl_teachersubject`
--
ALTER TABLE `tbl_teachersubject`
  ADD PRIMARY KEY (`ts_id`),
  ADD KEY `subject_id` (`sub_idno`),
  ADD KEY `teacher_id` (`teacher_idno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_section`
--
ALTER TABLE `tbl_section`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT for table `tbl_studentsubject`
--
ALTER TABLE `tbl_studentsubject`
  MODIFY `sc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_subject`
--
ALTER TABLE `tbl_subject`
  MODIFY `sub_idno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;

--
-- AUTO_INCREMENT for table `tbl_teachersubject`
--
ALTER TABLE `tbl_teachersubject`
  MODIFY `ts_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_teachersubject`
--
ALTER TABLE `tbl_teachersubject`
  ADD CONSTRAINT `tbl_teachersubject_ibfk_1` FOREIGN KEY (`sub_idno`) REFERENCES `tbl_subject` (`sub_idno`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_teachersubject_ibfk_2` FOREIGN KEY (`teacher_idno`) REFERENCES `tbl_teacher` (`teacher_idno`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
